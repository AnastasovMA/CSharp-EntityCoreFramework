﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trucks.Data.Models.Enums
{
    public enum CategoryType
    {
        Flatbed = 0,
        Jumbo = 1,
        Refrigerated = 2,
        Semi = 3
    }
}
