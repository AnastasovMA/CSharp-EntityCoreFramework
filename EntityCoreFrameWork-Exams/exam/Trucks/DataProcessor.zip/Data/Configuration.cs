﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Trucks;User Id=sa;Password=SoftUn!2022;";
    }
}